package MultiThread;

/*
 * Name: Mozeeb Abdulha
 * Student ID: 20075835
 * Program Name: Multithreaded Client/Server � User Authentication
 * Program Description: This program Checks if the student ID is in the database and if it is it will allow
 * the user to check the area of a circle
 * Date: 23/03/2020
 */

import java.io.*;
import java.net.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Client extends JFrame implements ActionListener {
	// Text field for receiving radius
	private JTextField jtf = new JTextField();

	// Text area to display contents
	private JTextArea jta = new JTextArea();
	
	private JButton jbtnSend = new JButton("Send");
	private JButton jbtnExit = new JButton("Exit");

	// IO streams
	private DataOutputStream toServer;
	private DataInputStream fromServer;
	
	// IP Address
	private InetAddress address;
		
	public static void main(String[] args) {
		new Client();
	}

	public Client() {
		// Panel p to hold the label and text field
		JPanel p = new JPanel();
		p.setLayout(new BorderLayout());
		p.add(new JLabel("Enter radius"), BorderLayout.WEST);
		p.add(jtf, BorderLayout.CENTER);
		jtf.setHorizontalAlignment(JTextField.RIGHT);

		setLayout(new BorderLayout());
		add(p, BorderLayout.SOUTH);
		add(new JScrollPane(jta), BorderLayout.CENTER);
		add(jbtnSend, BorderLayout.WEST);
		add(jbtnExit, BorderLayout.EAST);

		jbtnSend.addActionListener(this); // Register listener
		
		jbtnExit.addActionListener(this);
		
		setTitle("Client");
		setSize(500, 300);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true); // It is necessary to show the frame here!

		try {
			// Create a socket to connect to the server
			Socket socket = new Socket("localhost", 8000);
			
			address = socket.getInetAddress();

			// Create an input stream to receive data from the server
			fromServer = new DataInputStream(socket.getInputStream());

			// Create an output stream to send data to the server
			toServer = new DataOutputStream(socket.getOutputStream());
		} catch (IOException ex) {
			jta.append(ex.toString() + '\n');
		}
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
		if (e.getSource() == jbtnSend) {
			
			try {
				// Get the radius from the text field
				double radius = Double.parseDouble(jtf.getText().trim());

				// Send the radius to the server
				toServer.writeUTF("Client");
				toServer.writeDouble(radius);
				toServer.flush();
				
				double area = fromServer.readDouble();
				jtf.setText("");

				// Display to the text area
				jta.append("Server Address " + address + '\n');
				jta.append("Radius is " + radius + "\n");
				jta.append("Area received from the server is " + area + '\n');
			} catch (NumberFormatException e1) {
				jta.append("Invalid input... Radius must be a number" + '\n');
			} catch (IOException ex) {
				System.err.println(ex);
			}
			
		}
		
		else if (e.getSource() == jbtnExit) {
			System.exit(0);
		}
		
	}

}