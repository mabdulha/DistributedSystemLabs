package MultiThread;

/*
 * Name: Mozeeb Abdulha
 * Student ID: 20075835
 * Program Name: Multithreaded Client/Server � User Authentication
 * Program Description: This program Checks if the student ID is in the database and if it is it will allow
 * the user to check the area of a circle
 * Date: 23/03/2020
 */

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class Login extends JFrame implements ActionListener {
	
	// Defining components for the frame
	private JPanel contentPane;
	private JTextField textStudentId;
	private JButton btnLogin;
	private JTextArea txtrMessage;

	// IO streams
	private DataOutputStream toServer;
	private DataInputStream fromServer;

	private String message;

	public static void main(String[] args) {
		new Login();
	}

	public Login() {

		setTitle("Login");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 500, 400);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblLogin = new JLabel("Login");
		lblLogin.setHorizontalAlignment(SwingConstants.CENTER);
		lblLogin.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblLogin.setBounds(125, 10, 226, 42);
		contentPane.add(lblLogin);

		JLabel lblStudentId = new JLabel("Student ID");
		lblStudentId.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblStudentId.setHorizontalAlignment(SwingConstants.CENTER);
		lblStudentId.setBounds(125, 62, 226, 27);
		contentPane.add(lblStudentId);

		textStudentId = new JTextField();
		textStudentId.setToolTipText("Please enter Student ID");
		textStudentId.setHorizontalAlignment(SwingConstants.CENTER);
		textStudentId.setBounds(125, 109, 226, 19);
		contentPane.add(textStudentId);
		textStudentId.setColumns(10);

		btnLogin = new JButton("Login");
		btnLogin.setBounds(195, 149, 85, 21);
		btnLogin.addActionListener(this);
		contentPane.add(btnLogin);

		txtrMessage = new JTextArea();
		txtrMessage.setText("Welcome" + '\n');
		txtrMessage.setBounds(10, 197, 466, 136);
		contentPane.add(txtrMessage);
		setVisible(true);

		try {
			// Create a socket to connect to the server
			Socket socket = new Socket("localhost", 8000);
			// Create an input stream to receive data from the server
			fromServer = new DataInputStream(socket.getInputStream());
			// Create an output stream to send data to the server
			toServer = new DataOutputStream(socket.getOutputStream());
			txtrMessage.setText("Connected to the server on " + new Date() + '\n');
		} catch (IOException ex) {
			txtrMessage.append(ex.toString() + '\n');
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {

		try {
			int stdId = Integer.parseInt(textStudentId.getText().trim());

			// Send the id to the server
			toServer.writeUTF("Login");
			toServer.writeInt(stdId);
			toServer.flush();

			message = fromServer.readUTF();
			
			// Checking to see if response from server matches Welcome
			if (message.contains("Welcome")) {
				
				// Disabling text field and button after login
				textStudentId.setEditable(false);
				btnLogin.setEnabled(false);
				new Client();
				txtrMessage.append(message);
				
			}
			
			// Checking to see if response from server matches Sorry i.e unsuccessful
			if (message.contains("Sorry")) {
				
				txtrMessage.append(message);
				
			}

		} catch (NumberFormatException e1) {
			txtrMessage.append("Please enter a number" + '\n');
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}

}
