package MultiThread;

/*
 * Name: Mozeeb Abdulha
 * Student ID: 20075835
 * Program Name: Multithreaded Client/Server � User Authentication
 * Program Description: This program Checks if the student ID is in the database and if it is it will allow
 * the user to check the area of a circle
 * Date: 23/03/2020
 */

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import MultiThread.connection.*;

public class Server extends JFrame implements ActionListener {

	// Text area for displaying contents
	private JTextArea jta = new JTextArea();
	private JButton btnExit = new JButton("Exit");

	// Declaring variables
	private int studentId;
	private String fname;
	private String sname;

	boolean isStudentLoggedIn;

	// Name of the table in my database which i will be using
	private String tableName = "students";

	// Package to get the IP Address
	private InetAddress address;
	// The input and output streams to the client
	private DataInputStream inputFromClient;
	private DataOutputStream outputToClient;

	// Database
	private Connection conn = null;
	private Statement stmt;
	private ResultSet rs;
	private String sql;

	private String check;

	public static void main(String[] args) {
		new Server();
	}

	public Server() {

		// Place text area on the frame
		setLayout(new BorderLayout());
		add(new JScrollPane(jta), BorderLayout.CENTER);
		add(btnExit, BorderLayout.SOUTH);

		// Adding a listener to the button
		btnExit.addActionListener(this);

		// Setting title and dimensions of the frame
		setTitle("Server");
		setSize(500, 300);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true); // It is necessary to show the frame here!

		try {
			// Create a server socket
			ServerSocket serverSocket = new ServerSocket(8000);
			jta.append("Server started at " + new Date() + '\n');

			while (true) {

				// Listen for a connection request
				Socket s1 = serverSocket.accept();
				myClient c = new myClient(s1);
				c.start();
			}

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private class myClient extends Thread {
		// The socket the client is connected through
		private Socket socket;

		// The Constructor for the client
		public myClient(Socket socket) throws IOException {
			// Declare & Initialise input/output streams
			inputFromClient = new DataInputStream(socket.getInputStream());
			outputToClient = new DataOutputStream(socket.getOutputStream());
			// Getting the IP address
			address = socket.getInetAddress();
			jta.append("Client Host Name: " + address.getHostName() + '\n');
			jta.append("Client Host Address: " + address.getHostAddress() + '\n');
		}

		@Override
		public void run() {
			conn = null;
			try {
				
				// Getting a connection from the DB class
				conn = new DB().getConnection();

				while (true) {

					try {
						
						// Getting a response from the client
						check = inputFromClient.readUTF();
						
						// Checking to see if the response equals Client i.e the student is logged in
						if (check.equals("Client")) {
							
							isStudentLoggedIn = true;
						} 
						
						else {
							
							isStudentLoggedIn = false;
						}
						
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
					// If the user is logged in they can get radius
					if (isStudentLoggedIn == true) {
												
						// Receive radius from the client
						double radius = inputFromClient.readDouble();

						// Compute area
						double area = radius * radius * Math.PI;

						// Send area back to the client
						outputToClient.writeDouble(area);

						// Adding appropriate messages to the Text area
						jta.append("Radius received from client: " + radius + '\n');
						jta.append("Area found: " + area + '\n');

					}

					// If student is not logged in they can log in
					else if (isStudentLoggedIn == false) {

						// Getting the student id from the client where the student inputs it and checking if the ID exists in database
						studentId = inputFromClient.readInt();
						sql = "select * from " + tableName + " where STUD_ID = " + studentId;

						try {
							// Creating a statement and getting back results
							stmt = conn.createStatement();
							stmt.executeQuery(sql);
							rs = stmt.getResultSet();

							// If the result is back, i.e student exists, we log in the user
							if (rs.next()) {

								isStudentLoggedIn = true;
								fname = rs.getString("FNAME");
								sname = rs.getString("SNAME");

								jta.append("Sever Processing.... " + '\n');
								outputToClient.writeUTF("Welcome " + fname + " " + sname
										+ ".... You are now connected to the server" + '\n');

							} else {

								// Else we send a message to the user telling them their ID doesn't exist in the database
								jta.append("Sorry " + studentId + ". You are not a registered student. Byee " + '\n');
								outputToClient.writeUTF(
										"Sorry " + studentId + ". You are not a registered student. Byee " + '\n');
								isStudentLoggedIn = false;

							}

						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

					}
				}
			} catch (IOException e) {
				e.printStackTrace();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

		}

	}

	@Override
	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == btnExit) {
			
			// Closing the window
			System.exit(0);
		
		}
	}

}
