package MultiThread.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class DB {
	/** The name of the MySQL account to use (or empty for anonymous) */
	private final String userName = "root";

	/** The password for the MySQL account (or empty for anonymous) */
	private final String password = "";

	/** The name of the computer running MySQL */
	private final String serverName = "localhost";

	/** The port of the MySQL server (default is 3306) */
	private final int portNumber = 3306;

	/**
	 * The name of the database we are testing with (this default is installed with
	 * MySQL)
	 */
	private final String dbName = "assign2";

	private static Connection conn = null;
	private static Statement stmt = null;

	/**
	 * Get a new database connection
	 * 
	 * @return
	 * @throws SQLException
	 */
	public Connection getConnection() throws SQLException {
		try {
			Properties connectionProps = new Properties();
			connectionProps.put("user", this.userName);
			connectionProps.put("password", this.password);

			String url = "jdbc:mysql://" + this.serverName + ":" + this.portNumber + "/" + this.dbName;
			conn = DriverManager.getConnection(url, connectionProps);
            
			System.out.print("Successfully connected to database " + dbName + '\n');

			return conn;
		} catch (SQLException e) {
			System.out.print("Database connection failed... error: " + e + '\n');
			return null;
		}
	}
}
