package employeeManagement;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;

/**
 * Assignment 1: Employee Management JDBC
 * @author Mozeeb Abdulha
 * Student ID: 20075835
 * Module: Distributed Systems
 * 
 */

public class Main {

	// Initialising Variables
	public static Connection con = null;
	public static Statement st;
	public static ResultSet rs;
	public static String ssn="", name= "", address= "", gender="";
	public static double salary;
	public static Date dob;
	public static JButton btnNext, btnPrev, btnAdd, btnUpdate, btnDelete, btnClear;
	
	public static void main(String[] args) {

		// Initialising Components
		JFrame f = new JFrame();
		JLabel labelSsn = new JLabel("SSN: ");
		JLabel labelDob = new JLabel("DoB: ");
		JLabel labelName = new JLabel("Name: ");
		JLabel labelAddress = new JLabel("Address: ");
		JLabel labelSalary = new JLabel("Salary: ");
		JLabel labelGender = new JLabel("Gender: ");
		JTextField textSsn = new JTextField(9);
		JTextField textDob = new JTextField(10);
		JTextField textName = new JTextField(25);
		JTextField textAddress = new JTextField(50);
		JTextField textSalary = new JTextField(10);
		String[] genderList = {"Male", "Female", "Other"};
		JComboBox<String> selectGender = new JComboBox<String>(genderList);
		btnPrev = new JButton("Previous");
		btnNext = new JButton("Next");
		btnAdd = new JButton("Add");
		btnUpdate = new JButton("Update");
		btnDelete = new JButton("Delete");
		btnClear = new JButton("Clear");
		
		try {
			// Connecting to Database
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "");
			// Create Statement
			st= con.createStatement();
			// Executing statement to fetch everything from employee table
			rs= st.executeQuery("select * from employee");
			// Fetching the required variables from the database
			if(rs.next()) {
				ssn = rs.getString("SSN");
				dob = rs.getDate("DOB");
				name = rs.getString("Name");
				address = rs.getString("Address");
				salary = rs.getDouble("Salary");
				gender = rs.getString("Gender");
			}
			// Setting the data from database to the GUI
			textSsn.setText(ssn);
			textDob.setText(dob.toString());
			textName.setText(name);
			textAddress.setText(address);
			// Converting a double to string
			textSalary.setText(String.valueOf(salary));
			selectGender.setSelectedItem(gender);
		}
		catch (SQLException e) {
			System.out.print(e);
		}
		
		// Defining a new Panel which will display the UI elements and data
		JPanel p = new JPanel(new GridLayout(10,2));
		// Adding compnents to the panel
		p.add(labelSsn);
		p.add(textSsn);
		p.add(labelDob);
		p.add(textDob);
		p.add(labelName);
		p.add(textName);
		p.add(labelAddress);
		p.add(textAddress);
		p.add(labelSalary);
		p.add(textSalary);
		p.add(labelGender);
		p.add(selectGender);
		
		// Button to go to the previous record in the database
		p.add(btnPrev);
		// Setting previous false so user can't click previous on the first record
		btnPrev.setEnabled(false);
		btnPrev.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				try {
					if(rs.previous()) {
						btnPrev.setEnabled(true);
						btnNext.setEnabled(true);
						ssn = rs.getString("SSN");
						dob = rs.getDate("DOB");
						name = rs.getString("Name");
						address = rs.getString("Address");
						salary = rs.getDouble("Salary");
						gender = rs.getString("Gender");
					}
					textSsn.setText(ssn);
					textDob.setText(dob.toString());
					textName.setText(name);
					textAddress.setText(address);
					textSalary.setText(String.valueOf(salary));
					selectGender.setSelectedItem(gender);
					
					// When the cursor is on first item the 
					if(rs.isFirst()) {
						btnPrev.setEnabled(false);
					}
					
				} catch(SQLException err) {
					err.printStackTrace();
				}
			}
		});
		
		// Button to go to the next record in the database
		p.add(btnNext);
		btnNext.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				try {
					if(rs.next()) {
						btnPrev.setEnabled(true);
						btnNext.setEnabled(true);
						ssn = rs.getString("SSN");
						dob = rs.getDate("DOB");
						name = rs.getString("Name");
						address = rs.getString("Address");
						salary = rs.getDouble("Salary");
						gender = rs.getString("Gender");
					}
					
					textSsn.setText(ssn);
					textDob.setText(dob.toString());
					textName.setText(name);
					textAddress.setText(address);
					textSalary.setText(String.valueOf(salary));
					selectGender.setSelectedItem(gender);
					
					if(rs.isLast()) {
						btnNext.setEnabled(false);
					}
					
				} catch(SQLException err) {
					err.printStackTrace();
				}
			}
			
		});
		
		// Button to clear the text fields in the GUI
		p.add(btnClear);
		btnClear.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				textSsn.setText("");
				textDob.setText("");
				textName.setText("");
				textAddress.setText("");
				textSalary.setText("");
				selectGender.setSelectedItem(null);
			}

		});
		
		// Button to add a new record to the database
		p.add(btnAdd);
		btnAdd.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				try {		
					con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "");
					st= con.createStatement();
					String sql = "INSERT INTO `employee`(`SSN`, `DOB`, `Name`, `Address`, `Salary`, `Gender`) "
							+ "VALUES ('" + textSsn.getText() + "', '" + textDob.getText() + "', '" + textName.getText() + "', '" 
							+ textAddress.getText() + "', " + textSalary.getText() + ", '" + selectGender.getSelectedItem() + "')";
					// Validations to check there are no empty fields and character lengths
					if(textSsn.getText().isBlank() || textDob.getText().isBlank() || textName.getText().isBlank()
							|| textAddress.getText().isBlank() || textSalary.getText().isBlank() || selectGender.getSelectedItem() == null) {
						JOptionPane.showMessageDialog(null, "Cannot have Empty Fields");
					}
					if(textSsn.getText().length() < 7 || textSsn.getText().length() > 9 ) {
						JOptionPane.showMessageDialog(null, "Please enter valid SSN (1234567AB)");
					}
					if(textName.getText().length() > 25) {
						JOptionPane.showMessageDialog(null, "Maximum Character length for name is 25");
					}
					if(textAddress.getText().length() > 65) {
						JOptionPane.showMessageDialog(null, "Maximum Character Length for Address is 65");
					}
					// Regex so the user can only input the characters required for the database
					if(!textSalary.getText().matches("\\d+(\\.\\d{1,2})?")) {
						JOptionPane.showMessageDialog(null, "Please enter salary in correct format (20000.00)");
					}
					if(!textDob.getText().matches("^(19|20)\\d\\d[- /.](0[1-9]|1[012])[- /.](0[1-9]|[12][0-9]|3[01])$")) {
						JOptionPane.showMessageDialog(null, "Please enter Date in correct format (yyy-mm-dd)");
					}
					else {
						// Execute statement to add
						st.execute(sql);
					}
															
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		
		// Button to update the data in database
		p.add(btnUpdate);
		btnUpdate.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				try {
					con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "");
					st= con.createStatement();
					
					String sql = "UPDATE `employee` SET `SSN`= '" + textSsn.getText() + "',`DOB`= '" + textDob.getText() + "',"
							+ "`Name`= '" + textName.getText() + "',`Address`='" + textAddress.getText() + "',"
							+ "`Salary`= " + textSalary.getText() + ",`Gender`= '" + selectGender.getSelectedItem() + "' "
							+ "WHERE `ssn`='" + textSsn.getText() + "'";
					
					if(textSsn.getText().isBlank() || textDob.getText().isBlank() || textName.getText().isBlank()
							|| textAddress.getText().isBlank() || textSalary.getText().isBlank() || selectGender.getSelectedItem() == null) {
						JOptionPane.showMessageDialog(null, "Cannot have Empty Fields");
					}
					if(textSsn.getText().length() < 7 || textSsn.getText().length() > 9 ) {
						JOptionPane.showMessageDialog(null, "Please enter valid SSN (1234567AB)");
					}
					if(!textSalary.getText().matches("\\d+(\\.\\d{1,2})?")) {
						JOptionPane.showMessageDialog(null, "Please enter salary in correct format (20000.00)");
					}
					if(!textDob.getText().matches("^(19|20)\\d\\d[- /.](0[1-9]|1[012])[- /.](0[1-9]|[12][0-9]|3[01])$")) {
						JOptionPane.showMessageDialog(null, "Please enter Date in correct format (yyy-mm-dd)");
					}
					else {
						// Statement to update
						st.execute(sql);
					}
					
				}
				catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
			
		});
		
		// Button to delete the data by ssn
		p.add(btnDelete);
		btnDelete.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				try {
					con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "");
					st= con.createStatement();
					
					String sql = "DELETE FROM `employee` WHERE ssn='" + textSsn.getText() + "'";
					
					st.executeUpdate(sql);
					
				}
				catch (SQLException e1) {
					e1.printStackTrace();
				}
		
			}
			
		});
		
		// Setting the panel to the frame
		f.add(p);
		f.setVisible(true);
		f.pack();
	}
}
