package java_calculator_rmi;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.rmi.Naming;
import java.rmi.RemoteException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.UIManager;
import javax.swing.UIManager.LookAndFeelInfo;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;

public class Client implements ActionListener {

	// Defining components for layout
	private JFrame frame;

	public JTextArea jtaTop;
	public JTextArea jtaBottom;

	public JButton btn_divide;
	public JButton btn_multiply;
	public JButton btn_subtract;
	public JButton btn_add;
	public JButton btn_submit;
	public JButton btn_clear;
	public JButton btn_backspace;

	public JButton btn_0;
	public JButton btn_1;
	public JButton btn_2;
	public JButton btn_3;
	public JButton btn_4;
	public JButton btn_5;
	public JButton btn_6;
	public JButton btn_7;
	public JButton btn_8;
	public JButton btn_9;

	// Defining variables which will be used to function the program
	private static String a = "";
	private static String b = "";
	private static String operator = "";
	private static double answer = 0.0;
	static String message = "blank";

	// The CalculatorRem object "obj" is the identifier that is
	// used to refer to the remote object that implements
	// the CalculatorRem interface.
	static CalculatorRem obj = null;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {

		try {
			for (LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
				if ("Nimbus".equals(info.getName())) {
					UIManager.setLookAndFeel(info.getClassName());
					break;
				}
			}
		} catch (Exception e) {
			// If Nimbus is not available, you can set the GUI to another look and feel.
			e.printStackTrace();
		}

		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Client window = new Client();
					window.frame.setVisible(true);
					obj = (CalculatorRem) Naming.lookup("//" + "localhost" + "/CalculatorRem");
					message = obj.server();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Client() {
		initialize();
		jtaBottom.append("Please enter a Calculation \n");
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(700, 100, 350, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		jtaTop = new JTextArea();
		jtaTop.setBounds(10, 10, 316, 40);
		frame.getContentPane().add(jtaTop);

		btn_divide = new JButton("/");
		btn_divide.setFont(new Font("Arial", Font.PLAIN, 10));
		btn_divide.setBounds(10, 118, 60, 40);
		frame.getContentPane().add(btn_divide);
		btn_divide.addActionListener(this);

		btn_multiply = new JButton("*");
		btn_multiply.setFont(new Font("Arial", Font.PLAIN, 10));
		btn_multiply.setBounds(10, 168, 60, 40);
		frame.getContentPane().add(btn_multiply);
		btn_multiply.addActionListener(this);

		btn_subtract = new JButton("-");
		btn_subtract.setFont(new Font("Arial", Font.PLAIN, 10));
		btn_subtract.setBounds(10, 218, 60, 40);
		frame.getContentPane().add(btn_subtract);
		btn_subtract.addActionListener(this);

		btn_add = new JButton("+");
		btn_add.setFont(new Font("Arial", Font.PLAIN, 10));
		btn_add.setBounds(10, 268, 60, 40);
		frame.getContentPane().add(btn_add);
		btn_add.addActionListener(this);

		jtaBottom = new JTextArea();
		jtaBottom.setBounds(10, 328, 316, 125);
		frame.getContentPane().add(jtaBottom);
		jtaBottom.setEditable(false);

		btn_7 = new JButton("7");
		btn_7.setFont(new Font("Arial", Font.PLAIN, 10));
		btn_7.setBounds(95, 118, 60, 40);
		frame.getContentPane().add(btn_7);
		btn_7.addActionListener(this);

		btn_4 = new JButton("4");
		btn_4.setFont(new Font("Arial", Font.PLAIN, 10));
		btn_4.setBounds(95, 168, 60, 40);
		frame.getContentPane().add(btn_4);
		btn_4.addActionListener(this);

		btn_1 = new JButton("1");
		btn_1.setFont(new Font("Arial", Font.PLAIN, 10));
		btn_1.setBounds(95, 218, 60, 40);
		frame.getContentPane().add(btn_1);
		btn_1.addActionListener(this);

		btn_0 = new JButton("0");
		btn_0.setFont(new Font("Arial", Font.PLAIN, 10));
		btn_0.setBounds(95, 268, 60, 40);
		frame.getContentPane().add(btn_0);
		btn_0.addActionListener(this);

		btn_8 = new JButton("8");
		btn_8.setFont(new Font("Arial", Font.PLAIN, 10));
		btn_8.setBounds(180, 118, 60, 40);
		frame.getContentPane().add(btn_8);
		btn_8.addActionListener(this);

		btn_5 = new JButton("5");
		btn_5.setFont(new Font("Arial", Font.PLAIN, 10));
		btn_5.setBounds(180, 168, 60, 40);
		frame.getContentPane().add(btn_5);
		btn_5.addActionListener(this);

		btn_2 = new JButton("2");
		btn_2.setFont(new Font("Arial", Font.PLAIN, 10));
		btn_2.setBounds(180, 218, 60, 40);
		frame.getContentPane().add(btn_2);
		btn_2.addActionListener(this);

		btn_submit = new JButton("Submit");
		btn_submit.setFont(new Font("Arial", Font.PLAIN, 10));
		btn_submit.setBounds(180, 268, 146, 40);
		frame.getContentPane().add(btn_submit);
		btn_submit.addActionListener(this);

		btn_9 = new JButton("9");
		btn_9.setFont(new Font("Arial", Font.PLAIN, 10));
		btn_9.setBounds(265, 118, 60, 40);
		frame.getContentPane().add(btn_9);
		btn_9.addActionListener(this);

		btn_6 = new JButton("6");
		btn_6.setFont(new Font("Arial", Font.PLAIN, 10));
		btn_6.setBounds(265, 168, 60, 40);
		frame.getContentPane().add(btn_6);
		btn_6.addActionListener(this);

		btn_3 = new JButton("3");
		btn_3.setFont(new Font("Arial", Font.PLAIN, 10));
		btn_3.setBounds(265, 218, 60, 40);
		frame.getContentPane().add(btn_3);
		btn_3.addActionListener(this);

		btn_clear = new JButton("Clear");
		btn_clear.setFont(new Font("Arial", Font.PLAIN, 10));
		btn_clear.setBounds(10, 70, 145, 40);
		frame.getContentPane().add(btn_clear);
		btn_clear.addActionListener(this);

		btn_backspace = new JButton("Backspace");
		btn_backspace.setFont(new Font("Arial", Font.PLAIN, 10));
		btn_backspace.setBounds(181, 70, 145, 40);
		frame.getContentPane().add(btn_backspace);
		btn_backspace.addActionListener(this);

	}

	public void calculations(String oper) {

		try {

			jtaBottom.setText("");

			// Using a switch statement to trigger a method depending on the operator
			switch (oper) {

			case "addition":
				// Calling the ClaculatorRem object to use the methods
				answer = obj.addNum(Integer.parseInt(a), Integer.parseInt(b));
				jtaBottom.append(Integer.parseInt(a) + " + " + Integer.parseInt(b) + "\n");
				break;
			case "subtraction":
				answer = obj.subtractNum(Integer.parseInt(a), Integer.parseInt(b));
				jtaBottom.append(Integer.parseInt(a) + " - " + Integer.parseInt(b) + "\n");
				break;
			case "multiplication":
				answer = obj.multiplyNum(Integer.parseInt(a), Integer.parseInt(b));
				jtaBottom.append(Integer.parseInt(a) + " * " + Integer.parseInt(b) + "\n");
				break;
			case "division":
				answer = obj.divideNum(Integer.parseInt(a), Integer.parseInt(b));
				jtaBottom.append(Integer.parseInt(a) + " / " + Integer.parseInt(b) + "\n");
				break;

			}

			jtaBottom.append("Answer recieved from server " + answer + "\n");

		} catch (RemoteException e) {

			e.printStackTrace();

		}

	}

	public void submit(String operatorIn) throws ArrayIndexOutOfBoundsException, NumberFormatException {

		String text = jtaTop.getText();

		String[] values = text.split("[^\\w']+");

		System.out.print(values + "\n");

		a = values[0];
		b = values[1];

		if (!a.isEmpty() && !b.isEmpty() && !operator.isEmpty()) {

			switch (operatorIn) {

			case "addition":
				calculations("addition");
				break;

			case "subtraction":
				System.out.print("in sub");
				calculations("subtraction");
				break;

			case "multiplication":
				calculations("multiplication");
				break;

			case "division":
				calculations("division");
				break;
			}

		} else {

			jtaBottom.append(
					"Please enter a valid calculation... Number followed by an operator and then another number \n");

		}

	}

	@Override
	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == btn_0) {
			jtaTop.append("0");
		} else if (e.getSource() == btn_1) {
			jtaTop.append("1");
		} else if (e.getSource() == btn_2) {
			jtaTop.append("2");
		} else if (e.getSource() == btn_3) {
			jtaTop.append("3");
		} else if (e.getSource() == btn_4) {
			jtaTop.append("4");
		} else if (e.getSource() == btn_5) {
			jtaTop.append("5");
		} else if (e.getSource() == btn_6) {
			jtaTop.append("6");
		} else if (e.getSource() == btn_7) {
			jtaTop.append("7");
		} else if (e.getSource() == btn_8) {
			jtaTop.append("8");
		} else if (e.getSource() == btn_9) {
			jtaTop.append("9");
		} else if (e.getSource() == btn_add) {
			operator = "addition";
			jtaTop.append("+");
		} else if (e.getSource() == btn_subtract) {
			operator = "subtraction";
			jtaTop.append("-");
		} else if (e.getSource() == btn_multiply) {
			operator = "multiplication";
			jtaTop.append("*");
		} else if (e.getSource() == btn_divide) {
			operator = "division";
			jtaTop.append("/");
		} else if (e.getSource() == btn_clear) {
			jtaTop.setText("");
		} else if (e.getSource() == btn_submit) {
			try {
				submit(operator);
				jtaTop.setText("");
			} catch (ArrayIndexOutOfBoundsException | NumberFormatException e1) {
				jtaBottom.append(
						"Please enter a valid calculation... \nNumber followed by an operator and then another number \n");
			}
		} else if (e.getSource() == btn_backspace) {

			try {
				Document doc = jtaTop.getDocument();
				if (doc.getLength() > 0) {
					doc.remove(doc.getLength() - 1, 1);
				}
			} catch (BadLocationException ex) {
				ex.printStackTrace();
			}
		}

	}
}
