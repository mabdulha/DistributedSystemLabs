package java_calculator_rmi;

import java.awt.BorderLayout;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.ServerNotActiveException;
import java.rmi.server.UnicastRemoteObject;
import java.util.Date;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.UIManager;
import javax.swing.UIManager.LookAndFeelInfo;

/*
 * author: Mozeeb Abdulha
 * student id: 20075835
 * classname: Server
 * comment: the RMI server
 */

public class Server extends UnicastRemoteObject implements CalculatorRem {

	private static final long serialVersionUID = 1L;

	// Defining layout components
	private static JTextArea jta = new JTextArea();
	private JFrame jframe = new JFrame();

	protected Server() throws RemoteException {
		super();
		// Calling init method which will initialize the layout
		init();
	}

	public String server() {
		System.out.println("Invocation to Server was succesful! \n");
		jta.append("Invocation to Server was succesful! \n");
		return "Hello World from RMI server! \n";
	}

	public void init() {
		// Initializing the layout
		jframe.setLayout(new BorderLayout());
		jframe.add(new JScrollPane(jta), BorderLayout.CENTER);
		jframe.setTitle("Server");
		jframe.setBounds(300, 100, 350, 500);
		jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jframe.setVisible(true); // It is necessary to show the frame here!
		jta.setEditable(false);
	}

	/*
	 * Method which returns the total of 2 numbers added which is from RMI interface
	 * it takes in 2 integers... a and b
	 */

	@Override
	public double addNum(int a, int b) throws RemoteException {

		double total = a + b;

		try {

			System.out.print("Addition Request coming in from the client " + getClientHost() + "\n");
			jta.append("Addition Request coming in from the client " + getClientHost() + "\n");

		} catch (ServerNotActiveException e) {

			jta.append("Error in finding the client's IP Address");
			e.printStackTrace();

		}

		jta.append("Opnd1: " + a + "\n" + "Opnd2: " + b + "\n" + "Oprtr: + \n" + "Data to Client " + total + "\n");

		return total;

	}

	/*
	 * Method which returns the total of 2 numbers subtracted which is from RMI
	 * interface it takes in 2 integers... a and b
	 */

	@Override
	public double subtractNum(int a, int b) throws RemoteException {

		double total = a - b;

		try {

			System.out.print("Subtraction Request coming in from the client " + getClientHost() + "\n");
			jta.append("Subtraction Request coming in from the client " + getClientHost() + "\n");

		} catch (ServerNotActiveException e) {

			jta.append("Error in finding the client's IP Address");
			e.printStackTrace();

		}

		jta.append("Opnd1: " + a + "\n" + "Opnd2: " + b + "\n" + "Oprtr: - \n" + "Data to Client " + total + "\n");


		return total;

	}

	/*
	 * Method which returns the total of 2 numbers multiplied which is from RMI
	 * interface it takes in 2 integers... a and b
	 */

	@Override
	public double multiplyNum(int a, int b) throws RemoteException {

		double total = a * b;

		try {

			System.out.print("Multiplication Request coming in from the client " + getClientHost() + "\n");
			jta.append("Multiplication Request coming in from the client " + getClientHost() + "\n");

		} catch (ServerNotActiveException e) {

			jta.append("Error in finding the client's IP Address");
			e.printStackTrace();

		}

		jta.append("Opnd1: " + a + "\n" + "Opnd2: " + b + "\n" + "Oprtr: * \n" + "Data to Client " + total + "\n");


		return total;

	}

	/*
	 * Method which returns the total of 2 numbers divided which is from RMI
	 * interface it takes in 2 integers... a and b
	 */

	@Override
	public double divideNum(int a, int b) throws RemoteException {

		double total = a / b;

		try {

			System.out.print("Division Request coming in from the client " + getClientHost() + "\n");
			jta.append("Division Request coming in from the client " + getClientHost() + "\n");

		} catch (ServerNotActiveException e) {

			jta.append("Error in finding the client's IP Address");
			e.printStackTrace();

		}

		jta.append("Opnd1: " + a + "\n" + "Opnd2: " + b + "\n" + "Oprtr: / \n" + "Data to Client " + total + "\n");


		return total;

	}

	public static void main(String[] args) {

		// Using nimbus theme for gui
		try {
			for (LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
				if ("Nimbus".equals(info.getName())) {
					UIManager.setLookAndFeel(info.getClassName());
					break;
				}
			}
		} catch (Exception e) {
			// If Nimbus is not available, you can set the GUI to another look and feel.
			e.printStackTrace();
		}

		try {
			// Create an object of the Server class.
			Server obj = new Server();
			jta.append("Server started at " + new Date() + '\n');
			// Bind this object instance to the name "CalculatorRem" and port 1099.
			Registry registry = LocateRegistry.createRegistry(1099);
			registry.rebind("CalculatorRem", obj);
			jta.append("Server bound in registry \n");
		} catch (Exception e) {
			System.out.println("Server error: " + e.getMessage());
			e.printStackTrace();
		}

	}

}
