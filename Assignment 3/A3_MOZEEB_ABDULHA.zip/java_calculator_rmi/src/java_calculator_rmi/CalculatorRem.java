package java_calculator_rmi;

import java.rmi.Remote;
import java.rmi.RemoteException;

/*
 * author: Mozeeb Abdulha
 * student id: 20075835
 * classname: CalculatorRem
 * comment: the remote interface
 */

public interface CalculatorRem extends Remote {

	// This method takes in 2 integers and will add them
	public double addNum(int a, int b) throws RemoteException;
	// This method takes in 2 integers and will subtract them
	public double subtractNum(int a, int b) throws RemoteException;
	// This method takes in 2 integers and will multiply them
	public double multiplyNum(int a, int b) throws RemoteException;
	// This method takes in 2 integers and will divide them
	public double divideNum(int a, int b) throws RemoteException;
	String server() throws RemoteException;
	
}
